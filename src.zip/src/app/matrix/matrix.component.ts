import { Component, OnInit } from '@angular/core';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

@Component({
  selector: 'app-matrix',
  templateUrl: './matrix.component.html',
  styleUrls: ['./matrix.component.scss']
})
export class MatrixComponent implements OnInit {
  imagePositions = [
    { "x": 9.5, "y": 0, "z": -3.5, img: 'https://pbs.twimg.com/media/FPRFvIpWYAMnfYI.jpg:large' },
    { "x": 9.5, "y": 0, "z": -2.5, img: 'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png' },
    { "x": 9.5, "y": 0, "z": -6.5, img: 'https://pbs.twimg.com/media/FPRFvIpWYAMnfYI.jpg:large' },
    { "x": 8.5, "y": 0, "z": -1.5, img: 'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png' },
    { "x": 8.5, "y": 0, "z": -4.5, img: 'https://pbs.twimg.com/media/FPRFvIpWYAMnfYI.jpg:large' },
    { "x": 8.5, "y": 0, "z": -5.5, img: 'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png' },
    { "x": 8.5, "y": 0, "z": -6.5, img: 'https://pbs.twimg.com/media/FPRFvIpWYAMnfYI.jpg:large' },
    { "x": 8.5, "y": 0, "z": -2.5, img: 'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png' },
    { "x": 9.5, "y": 0, "z": -4.5, img: 'https://i.insider.com/62b32d27c38f470019c6bc26?width=700' },
    { "x": 7.5, "y": 0, "z": -4.5, img: 'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png' },
    { "x": 1.5, "y": 0, "z": -4.5, img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU' },
    { "x": 2.5, "y": 0, "z": 3.5, img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU' },
    { "x": 7.5, "y": 0, "z": -4.5, img: 'https://static.ffx.io/images/$width_584/t_resize_width/q_86%2Cf_auto/a76c1590a4ab2ae7219ea36817a6e2dfd6a00c27' },
    { "x": 4.5, "y": 0, "z": -4.5, img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU' },
    { "x": -0.5, "y": 0, "z": -1.5, img: 'https://static.ffx.io/images/$width_584/t_resize_width/q_86%2Cf_auto/a76c1590a4ab2ae7219ea36817a6e2dfd6a00c27' },
    { "x": 9.5, "y": 0, "z": 4.5, img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU' },
    { "x": 3.5, "y": 0, "z": -1.5, img: 'https://static.ffx.io/images/$width_584/t_resize_width/q_86%2Cf_auto/a76c1590a4ab2ae7219ea36817a6e2dfd6a00c27' },
    { "x": 2.5, "y": 0, "z": 2.5, img: 'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png' },
    { "x": 9.5, "y": 0, "z": 6.5, img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU7' },
    { "x": 8.5, "y": 0, "z": -1.5, img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU7' }
  ]
  loader = new THREE.TextureLoader();
  renderer = new THREE.WebGLRenderer();
  canvasholder: any;
  scene = new THREE.Scene();
  grid: any;
  highlightMesh: any;
  camera: any;
  orbit: any;
  planeMesh: any;
  mousePosition = new THREE.Vector2();
  raycaster = new THREE.Raycaster();
  intersects: any;
  objects: any = []
  objectExist:any;

  constructor() { }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    this.canvasholder = document.querySelector('#canvasholder');

    this.renderer.setSize(this.canvasholder.clientWidth, this.canvasholder.clientHeight);

    this.canvasholder.appendChild(this.renderer.domElement);

    this.camera = new THREE.PerspectiveCamera(
      45,
      this.canvasholder.clientWidth / this.canvasholder.clientHeight,
      0.1,
      1000
    );

    this.orbit = new OrbitControls(this.camera, this.renderer.domElement); //creates orbit/orbit controls to contol the page through mouse

    this.camera.position.set(10, 15, -10);

    this.orbit.update();

    this.planeMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(20, 20),
      new THREE.MeshBasicMaterial({
        color: 0x02469f,
        side: THREE.DoubleSide, 
        visible: true
      })
    );

    this.planeMesh.rotateX(-Math.PI / 2);
    this.scene.add(this.planeMesh);
    this.planeMesh.name = 'ground';

    //Creating Grid
    this.grid = new THREE.GridHelper(20, 20);
    this.scene.add(this.grid);

    this.highlightMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.MeshBasicMaterial({
        side: THREE.DoubleSide,
        transparent: true
      })
    );
    this.highlightMesh.rotateX(-Math.PI / 2);
    this.highlightMesh.position.set(0.5, 0, 0.5);
    this.scene.add(this.highlightMesh);

    this.imagePositions.forEach(item => {
      this.createImage(item.img, item.x, item.y, item.z);
    })

    window.addEventListener('mousemove',  (e)=> {
      this.mousePosition.x = (e.clientX / this.canvasholder.clientWidth) * 2 - 1;
      this.mousePosition.y = -(e.clientY / this.canvasholder.clientHeight) * 2 + 1;
      this.raycaster.setFromCamera(this.mousePosition, this.camera);
      this.intersects = this.raycaster.intersectObjects(this.scene.children);
      this.intersects.forEach((intersect:any) => {
        if (intersect.object.name === 'ground') {
          const highlightPos = new THREE.Vector3().copy(intersect.point).floor().addScalar(0.5);
          this.highlightMesh.position.set(highlightPos.x, 0, highlightPos.z);

          this.objectExist = this.objects.find((object:any) => {
            return (object.position.x === this.highlightMesh.position.x)
              && (object.position.z === this.highlightMesh.position.z)
          });

          if (!this.objectExist)
            this.highlightMesh.material.color.setHex(0xc4bb0c);
          else
            this.highlightMesh.material.color.setHex(0xFF0000);
        }
      });
    });

    window.addEventListener('mousedown', (event)=> {
      console.log(this.highlightMesh.position, this.imagePositions );
      this.objectExist = this.imagePositions.find((object)=> {
          return (object.x === this.highlightMesh.position.x)
          && (object.z === this.highlightMesh.position.z)
      });
      
      console.log(this.objectExist,'objectexist');
      if(this.objectExist) {
          let f:any = document.querySelector('#pickedImgtag');
          let d = f.src = this.objectExist.img;
          console.log(this.objectExist);
      }
   
  });

    this.renderer.setAnimationLoop((time:any) => {
      this.highlightMesh.material.opacity = 1 + Math.sin(time / 120);
      this.objects.forEach( (object:any) => {
        object.rotation.x = time / 1000;
        object.rotation.z = time / 1000;
        object.position.y = 0.5 + 0.5 * Math.abs(Math.sin(time / 1000));
      });
      this.renderer.render(this.scene, this.camera);
    });

    window.addEventListener('resize',  () => {
      this.camera.aspect = this.canvasholder.clientWidth / this.canvasholder.clientHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(this.canvasholder.clientWidth, this.canvasholder.clientHeight);
    });

  }
  
  createImage(image: any, x: any, y: any, z: any) {
    const plane = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.MeshBasicMaterial({
        color: 0xfcba03,
        side: THREE.FrontSide,
        map: this.loader.load(image),
        visible: true
      })
    );
    plane.position.set(x, y, z);
    plane.rotateX(-Math.PI / 2);
    this.scene.add(plane);
    plane.name = 'tab';
  }


}
