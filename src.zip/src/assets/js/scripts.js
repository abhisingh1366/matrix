import * as THREE from 'three';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';

var imagePositions =  [
                        {"x":9.5,"y":0,"z":-3.5, img:'https://pbs.twimg.com/media/FPRFvIpWYAMnfYI.jpg:large'},
                        {"x":9.5,"y":0,"z":-2.5, img:'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png'},
                        {"x":9.5,"y":0,"z":-6.5, img:'https://pbs.twimg.com/media/FPRFvIpWYAMnfYI.jpg:large'},
                        {"x":8.5,"y":0,"z":-1.5, img:'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png'},
                        {"x":8.5,"y":0,"z":-4.5, img:'https://pbs.twimg.com/media/FPRFvIpWYAMnfYI.jpg:large'},
                        {"x":8.5,"y":0,"z":-5.5, img:'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png'},
                        {"x":8.5,"y":0,"z":-6.5, img:'https://pbs.twimg.com/media/FPRFvIpWYAMnfYI.jpg:large'},
                        {"x":8.5,"y":0,"z":-2.5, img:'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png'},
                        {"x":9.5,"y":0,"z":-4.5, img:'https://i.insider.com/62b32d27c38f470019c6bc26?width=700'},
                        {"x":7.5,"y":0,"z":-4.5, img:'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png'},
                        {"x":1.5,"y":0,"z":-4.5, img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU'},
                        {"x":2.5,"y":0,"z": 3.5, img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU'},
                        {"x":7.5,"y":0,"z":-4.5, img:'https://static.ffx.io/images/$width_584/t_resize_width/q_86%2Cf_auto/a76c1590a4ab2ae7219ea36817a6e2dfd6a00c27'},
                        {"x":4.5,"y":0,"z":-4.5, img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU'},
                        {"x":-0.5,"y":0,"z":-1.5, img:'https://static.ffx.io/images/$width_584/t_resize_width/q_86%2Cf_auto/a76c1590a4ab2ae7219ea36817a6e2dfd6a00c27'},
                        {"x":9.5,"y":0,"z":4.5, img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU'},
                        {"x":3.5,"y":0,"z":-1.5, img:'https://static.ffx.io/images/$width_584/t_resize_width/q_86%2Cf_auto/a76c1590a4ab2ae7219ea36817a6e2dfd6a00c27'},
                        {"x":2.5,"y":0,"z":2.5, img:'https://miro.medium.com/max/980/1*3iesg_sr8kC6NYN2iiFHRQ.png'},
                        {"x":9.5,"y":0,"z":6.5, img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU7'},
                        {"x":8.5,"y":0,"z":-1.5, img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtfZvjZp0N7rBzyzhTMLHVPak5j59zd1zpHg&usqp=CAU7'}
                    ]
var loader = new THREE.TextureLoader();
let canvasholder = document.querySelector('#canvasholder');
const renderer = new THREE.WebGLRenderer();
renderer.setSize(canvasholder.clientWidth, canvasholder.clientHeight);
canvasholder.appendChild(renderer.domElement);

const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(
    45,
    canvasholder.clientWidth / canvasholder.clientHeight,
    0.1,
    1000
);

//Creating axes
// var axes = new THREE.AxesHelper(20);
// scene.add(axes); //display axes

const orbit = new OrbitControls(camera, renderer.domElement); //creates orbit/orbit controls to contol the page through mouse

camera.position.set(10, 15, -10);

orbit.update();

//Ground Created
const planeMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(20, 20),
    new THREE.MeshBasicMaterial({
        color: 0x02469f,
        side: THREE.DoubleSide,
        visible: true
    })
);
planeMesh.rotateX(-Math.PI / 2);
scene.add(planeMesh);
planeMesh.name = 'ground';

//Creating Grid
const grid = new THREE.GridHelper(20, 20);
scene.add(grid);

const highlightMesh = new THREE.Mesh(
    new THREE.PlaneGeometry(1, 1),
    new THREE.MeshBasicMaterial({
        side: THREE.DoubleSide,
        transparent: true
    })
);
highlightMesh.rotateX(-Math.PI / 2);
highlightMesh.position.set(0.5, 0, 0.5);
scene.add(highlightMesh);

const mousePosition = new THREE.Vector2();
const raycaster = new THREE.Raycaster();
let intersects;

imagePositions.forEach(item => {
    createImage(scene, item.img, item.x, item.y, item.z);
})
console.log(imagePositions)

window.addEventListener('mousemove', function(e) {
    mousePosition.x = (e.clientX / canvasholder.clientWidth) * 2 - 1;
    mousePosition.y = -(e.clientY / canvasholder.clientHeight) * 2 + 1;
    raycaster.setFromCamera(mousePosition, camera);
    intersects = raycaster.intersectObjects(scene.children);
    intersects.forEach(function(intersect) {
        if(intersect.object.name === 'ground') {
            const highlightPos = new THREE.Vector3().copy(intersect.point).floor().addScalar(0.5);
            highlightMesh.position.set(highlightPos.x, 0, highlightPos.z);

            const objectExist = objects.find(function(object) {
                return (object.position.x === highlightMesh.position.x)
                && (object.position.z === highlightMesh.position.z)
            });

            if(!objectExist)
                highlightMesh.material.color.setHex(0xc4bb0c);
            else
                highlightMesh.material.color.setHex(0xFF0000);
        }
    });
});

// const sphereMesh = new THREE.Mesh(
//     new THREE.SphereGeometry(0.4, 4, 2),
//     new THREE.MeshBasicMaterial({
//         wireframe: true,
//         color: 0xFFEA00
//     })
// );

const objects = [];

window.addEventListener('mousedown', function(event) {
    console.log(highlightMesh.position, imagePositions );
    const objectExist = imagePositions.find(function(object) {
        return (object.x === highlightMesh.position.x)
        && (object.z === highlightMesh.position.z)
    });
    
    console.log(objectExist,'hjgjg');
    if(objectExist) {
        document.querySelector('#pickedImgtag').src = objectExist.img;
        console.log(objectExist);
    }

    // const objectExist = objects.find(function(object) {
    //     return (object.position.x === highlightMesh.position.x)
    //     && (object.position.z === highlightMesh.position.z)
    // });

    // if(!objectExist) {
    //     intersects.forEach(function(intersect) {
    //         if(intersect.object.name === 'ground') {
    //             createImage(scene,'https://s3.amazonaws.com/duhaime/blog/tsne-webgl/assets/cat.jpg', highlightMesh.position.x, highlightMesh.position.y, highlightMesh.position.z)                // const sphereClone = sphereMesh.clone();
    //             // sphereClone.position.copy(highlightMesh.position);
    //             // scene.add(sphereClone);
    //             // objects.push( );
    //             // highlightMesh.material.color.setHex(0xFF0000);
    //         }
    //     });
    // }
    // console.log(scene.children.length);  
});

function animate(time) {
    highlightMesh.material.opacity = 1 + Math.sin(time / 120);
    objects.forEach(function(object) {
        object.rotation.x = time / 1000;
        object.rotation.z = time / 1000;
        object.position.y = 0.5 + 0.5 * Math.abs(Math.sin(time / 1000));
    });
    renderer.render(scene, camera);
}

renderer.setAnimationLoop(animate);

window.addEventListener('resize', function() {
    camera.aspect = canvasholder.clientWidth / canvasholder.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(canvasholder.clientWidth, canvasholder.clientHeight);
});

function createImage(scene, image, x,y,z) {
    const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(1,1),
        new THREE.MeshBasicMaterial({
            color: 0xfcba03,
            side: THREE.FrontSide,
            map: loader.load(image),
            visible: true
        })
    );
    plane.position.set(x,y,z);
    plane.rotateX(-Math.PI / 2);
    scene.add(plane);
    plane.name = 'tab';
}